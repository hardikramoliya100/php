<div class="jumbotron text-center">
    <h1 class="">LOGIN</h1>

</div>
<div class="container">
    <div class="row">
        <div class="col-lg-4 offset-lg-4">
            <div class="card">
                <div class="card-header text-center">
                    LOGIN
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data" id="form">

                        <div class="row">
                            <div class="col">
                                <label for="">User Name Or Email</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <input type="text" placeholder="Enter Username or Email " class="form-control" name="username" id="username">
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col">
                                <label for="">Password</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <input type="password" placeholder="Enter Password" class="form-control" name="password" id="password">
                            </div>
                        </div>
                        
                        

                        <div class="row mt-3 ">
                            <div class="col text-center">
                                <input type="submit" class="btn btn-primary" name="login" id="login" value="login">

                            </div>
                        </div>
                    </form>
                    <a href="Registration">Registration</a>

                </div>
            </div>
        </div>
    </div>

</div>